﻿using FPS.Entity;

namespace FPS.Actions
{
    public abstract class AbstractDealDamage : IDealDamage
    {
        public virtual int DamageAmount { get; set; }
        public abstract void DealDamage(IEntity entity);
    }
}