﻿using System;
using UnityEngine;

namespace FPS.Actions
{
    public class ActionTemplate<T>
    {
        private GameObject _gameObject;
        private Action<T> _action;
        
        public ActionTemplate(GameObject gameObject, Action<T> action)
        {
            _gameObject = gameObject;
            _action = action;
        }

        public bool Invoke()
        {
            var component = GetComponent();
            if (component != null)
            {
                _action.Invoke(component);
                return true;
            }

            return false;
        }

        private T GetComponent()
        {
            return _gameObject.GetComponent<T>();
        }
    }
}