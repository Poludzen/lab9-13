﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace FPS.Actions
{
    public class ApplyAction
    {
        private GameObject _gameObject;
        private List<Func<bool>> _actions;

        public ApplyAction(GameObject gameObject)
        {
            _gameObject = gameObject;
            _actions = new List<Func<bool>>();
        }

        public void Add<T>(Action<T> action)
        {
            _actions.Add(new ActionTemplate<T>(_gameObject, action).Invoke);
        }

        public bool Run()
        {
            var result = false;
            foreach (var action in _actions)
            {
                result = result || action.Invoke();
            }

            return result;
        }
    }
}