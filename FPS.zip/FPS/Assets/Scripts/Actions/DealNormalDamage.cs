﻿using FPS.Entity;
using UnityEngine;

namespace FPS.Actions
{
    public class DealNormalDamage : AbstractDealDamage
    {
        public override int DamageAmount { get; set; } = 50;

        public override void DealDamage(IEntity entity)
        {
            entity.Health -= DamageAmount;
            Debug.Log($"deal {DamageAmount} to {entity.GetType()}");
            if (!entity.Dead && entity.Health <= 0)
            {
                entity.Kill();
            }
        }
    }
}