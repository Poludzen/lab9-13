﻿namespace FPS.Actions
{
    public interface IAction
    {
        
    }
}