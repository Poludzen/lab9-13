﻿using FPS.Entity;

namespace FPS.Actions
{
    public interface IDealDamage
    {
        int DamageAmount { get; set; }
        void DealDamage(IEntity entity);
    }
}