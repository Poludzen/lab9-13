﻿using FPS.FOV;
using UnityEngine;

namespace FPS.Entity
{
    public class EnemyBehaviour : MonoBehaviour
    {
        private const string MOVE_CONDITION = "Move";
        private const  string IDLE_CONDITION = "Idle";
        private const string SHOOT_CONDITION = "Shoot";
        private static readonly int Move = Animator.StringToHash(MOVE_CONDITION);
        private static readonly int Shoot = Animator.StringToHash(SHOOT_CONDITION);
        private static readonly int Idle1 = Animator.StringToHash(IDLE_CONDITION);
        
        [SerializeField] private FieldOfView _fieldOfView;
        [SerializeField] private EnemyMovement _enemyMovement;
        [SerializeField] private EnemyShooting _enemyShooting;
        [SerializeField] private Animator _animator;
        
        enum enemyStates
        {
            MoveToPlayersRange = 0,
            ShootPlayer = 1,
            Idle = 2
        }

        private bool IsPlayerVisible =>_fieldOfView.IsPlayerVisible;
        private bool IsPlayerInRange=>_fieldOfView.IsPlayerInRange;
        private bool IsPlayerAlive => true;
        private enemyStates _currentState = enemyStates.Idle;

        private void OnEnable()
        {
            Singleton.SetUp();
        }
        private void Update()
        {
            StateMachine();
        }

        private void StateMachine()
        {
            var state = enemyStates.Idle;
            if (IsPlayerAlive)
            {
                state = enemyStates.MoveToPlayersRange;
                if (IsPlayerInRange)
                {
                    if (IsPlayerVisible)
                    {
                        state = enemyStates.ShootPlayer;
                    }
                }
            }
            
            switch (state)
            {
                case enemyStates.Idle:
                    Idle(state);
                    break;
                case enemyStates.MoveToPlayersRange:
                    MoveToPlayersRange(state);
                    break;
                case enemyStates.ShootPlayer:
                    ShootPlayer(state);
                    break;
            }
            _currentState = state;
        }

        private void Idle(enemyStates newState)
        {
            if (_currentState != newState)
            {
                _enemyMovement.Move(false);
            }

            _animator.SetBool(Shoot, false);
            _animator.SetBool(Move, false);
            _animator.SetBool(IDLE_CONDITION, true);
        }

        private void MoveToPlayersRange(enemyStates newState)
        {
            if (_currentState != newState)
            {
                _enemyMovement.Move(true);
            }

            _animator.SetBool(Shoot, false);
            _animator.SetBool(Idle1, false);
            _animator.SetBool(Move, true);
        }

        private void ShootPlayer(enemyStates newState)
        {
            if (_currentState != newState)
            {
                _enemyMovement.Move(false);
                _animator.SetBool(Move, false);
                _animator.SetBool(Idle1, false);
            }

            if (_enemyShooting.TryShoot())
            {
                _animator.Play(Shoot);
            }
        }
    }
}