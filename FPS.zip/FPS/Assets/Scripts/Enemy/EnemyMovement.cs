using UnityEngine;
using UnityEngine.AI;

namespace FPS.Entity
{
    public class EnemyMovement : MonoBehaviour
    {
        [SerializeField] private NavMeshAgent _navMeshAgent;
        private Vector3 _destination;
        private bool _move;

        private void Update()
        {
            if (_move)
            {
                Move();
            }
        }

        public void Move(bool allow)
        {
            _navMeshAgent.isStopped = !allow;
            _move = allow;
        }

        private void Move()
        {
            _destination = Singleton.GameManager.GetPlayerPosition;
            _navMeshAgent.SetDestination(_destination);
        }
    }
}