﻿using System;
using FPS.Weapons;
using UnityEngine;
using UnityEngine.Scripting;

namespace FPS.Entity
{
    public class EnemyShooting: MonoBehaviour
    {
        [SerializeField] private AbstractShootingWeapon _abstractShootingWeapon;
        [SerializeField] private Transform _forwardPosition;

        public bool TryShoot() => _abstractShootingWeapon.IsAvailableToShoot;

        [Preserve]
        private void FireEvent()
        {
            RotateTowardsPlayer();
            _abstractShootingWeapon.Fire(_forwardPosition.forward);
        }

        private void RotateTowardsPlayer()
        {
            _forwardPosition.rotation = Quaternion.LookRotation(Singleton.GameManager.GetPlayerPosition - _forwardPosition.position);
        }
    }
}