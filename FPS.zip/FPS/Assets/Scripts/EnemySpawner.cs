using System.Collections.Generic;
using FPS.Entity;
using UnityEngine;
using Random = System.Random;

namespace FPS
{
    public class EnemySpawner : MonoBehaviour
    {
        [SerializeField] private Transform[] _spawnPositions;
        [SerializeField] private int _maxEnemiesNumber;
        private List<IEntity> _aliveEnemies;

        private void OnEnable()
        {
            _aliveEnemies = new List<IEntity>();
        }

        private void Update()
        {
            var enemiesDead = _maxEnemiesNumber - _aliveEnemies.Count;
            if (enemiesDead > 0)
            {
                SpawnEnemy(enemiesDead);
            }
        }

        private void SpawnEnemy(int enemiesToSpawn)
        {
            if (enemiesToSpawn == 0)
            {
                return;
            }

            for (var i = 0; i < enemiesToSpawn; i++)
            {
                var entity =
                    GetRandomEntityFromPool(_spawnPositions[GetRandomElement(_spawnPositions.Length)].position);
                _aliveEnemies.Add(entity);
                entity.OnDeath += RemoveFromList;
            }
        }

        private int GetRandomElement(int collectionLength) => new Random().Next(0, collectionLength);

        private AbstractEntity GetRandomEntityFromPool(Vector3 position)
        {
            var result =new Random().Next(0, 3);
            if (result == 0)
            {
                return Singleton.GameManager.BarrelsPool.Get(position, true);
            }
            else
            {
                return Singleton.GameManager.SoldersPool.Get(position, true);
            }
        }

        private void RemoveFromList(IEntity entity)
        {
            _aliveEnemies.Remove(entity);
            entity.OnDeath -= RemoveFromList;
        }
    }
}