﻿using System;
using FPS.Pool;
using UnityEngine;

namespace FPS.Entity
{
    public class AbstractEntity : MonoBehaviour, IEntity, IPoolItem
    {
        public virtual int Health { get; set; } = 60;
        public bool Dead { get; set; }
        public event Action<IEntity> OnDeath;
        public event Action OnReturnToPool;

        public void Kill()
        {
            Health = 0;
            Dead = true;
            OnReturnToPool?.Invoke();
            gameObject.SetActive(false);
            OnDeath?.Invoke(this);
        }
    }
}