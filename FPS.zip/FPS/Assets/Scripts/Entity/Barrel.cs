namespace FPS.Entity
{
    public class Barrel : AbstractEntity
    {
        public override int Health { get; set; } = 30;
    }
}