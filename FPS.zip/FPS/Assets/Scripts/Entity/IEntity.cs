﻿using System;

namespace FPS.Entity
{
    public interface IEntity
    {
        int Health { get; set; }
        bool Dead { get; set; }
        void Kill();
        event Action<IEntity> OnDeath;
    }
}