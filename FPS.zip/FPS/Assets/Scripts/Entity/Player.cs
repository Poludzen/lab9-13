﻿namespace FPS.Entity
{
    public class Player: AbstractEntity
    {
        public override int Health { get; set; } = 1200;
    }
}