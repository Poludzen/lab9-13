﻿using FPS.Pool;

namespace FPS.Entity
{
    public class Solder : AbstractEntity
    {
    }
}