﻿using FPS.Pool;
using UnityEngine;

namespace FPS
{
    public class GameManager: MonoBehaviour
    {
        [SerializeField] private Transform _playerPosition;
        public Vector3 GetPlayerPosition => _playerPosition.position;
        [SerializeField] private ShootingParticlePool _shootingParticlePool;
        public ShootingParticlePool ShootingParticlePool => _shootingParticlePool;
        [SerializeField] private BarrelsPool _barrelsPool;
        public BarrelsPool BarrelsPool => _barrelsPool;
        [SerializeField] private SoldersPool _soldersPool;
        public SoldersPool SoldersPool => _soldersPool;
    }

    public static class Singleton
    {
        public static void SetUp()
        {
            if (_gameManager==null)
            {
                _gameManager = Object.FindObjectOfType<GameManager>();
            }
        }

        private static GameManager _gameManager;
        public static GameManager GameManager => _gameManager;
    }
}