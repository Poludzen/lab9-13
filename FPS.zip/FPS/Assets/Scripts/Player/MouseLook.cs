﻿using FPS.Common;
using UnityEngine;

namespace FPS.Player
{
    public class MouseLook : MonoBehaviour
    {
        public float mouseSensitivity = 180;
        public Transform player;

        private float _rotationOnX;

        private void Start()
        {
            Cursor.lockState = CursorLockMode.Locked;
        }

        private void Update()
        {
            LockAndUnlockCursor();
            var mouseY = Input.GetAxis(MouseAxis.MOUSE_Y) * Time.deltaTime * mouseSensitivity;
            var mX = Input.GetAxis(MouseAxis.MOUSE_X) * Time.deltaTime * mouseSensitivity;

            _rotationOnX -= mouseY;
            _rotationOnX = Mathf.Clamp(_rotationOnX, -90, 90);
            transform.localEulerAngles = new Vector3(_rotationOnX, 0, 0);
            player.Rotate(Vector3.up * mX);
        }

        private void LockAndUnlockCursor()
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (Cursor.lockState == CursorLockMode.Locked)
                {
                    Cursor.lockState = CursorLockMode.None;
                }
                else
                {
                    Cursor.lockState = CursorLockMode.Locked;
                    Cursor.visible = false;
                }
            }
        } // lock and unlock
    }
}