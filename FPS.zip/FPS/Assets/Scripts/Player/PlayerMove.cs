﻿using UnityEngine;
using FPS.Common;

namespace FPS.Player
{
    public class PlayerMove : MonoBehaviour
    {
        public float speed = 5f;
        [SerializeField] private CharacterController character_Controller;
        private Vector3 move_Direction;

        private void Update()
        {
            MoveThePlayer();
        }

        private void MoveThePlayer()
        {
            move_Direction = new Vector3(
                Input.GetAxisRaw(Axis.HORIZONTAL),
                0f,
                Input.GetAxisRaw(Axis.VERTICAL)).normalized;
            move_Direction = transform.TransformDirection(move_Direction);
            if (move_Direction.magnitude >= 0.1f)
            {
                character_Controller.Move(move_Direction * (speed * Time.deltaTime));
            }
        }
    }
}