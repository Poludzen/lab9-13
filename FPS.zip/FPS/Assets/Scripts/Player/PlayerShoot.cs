using FPS.Weapons;
using UnityEngine;

namespace FPS.Player
{
    public class PlayerShoot : MonoBehaviour
    {
        [SerializeField] private AbstractShootingWeapon _abstractShootingWeapon;
        [SerializeField] private Transform _playerForwardPosition;

        private void Update()
        {
            if (Input.GetMouseButton(0))
            {
                Fire();
            }
        }

        private void Fire()
        {
            if (_abstractShootingWeapon.IsAvailableToShoot)
            {
                _abstractShootingWeapon.Fire(_playerForwardPosition.forward);
            }
        }
    }
}