﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace FPS.Pool
{
    public class AbstractPool<T> : MonoBehaviour, IPool<T> where T : MonoBehaviour, IPoolItem
    {
        public virtual int PoolLimit { get; set; } = 20;
        public virtual List<T> Pool { get; set; }
        [SerializeField] private T _defaultItem;

        private void Start()
        {
            SetupPool();
        }

        public T Get()
        {
            if (Pool.Count > 0)
            {
                var poolItem = Pool[0];
                Pool.RemoveAt(0);
                return poolItem;
            }
            else
            {
                Debug.LogError($"{this} pool is empty");
                return default;
            }
        }

        public T Get(Transform targetPosition, bool setActive = false)
        {
            var item = Get();
            var transform1 = item.transform;
            transform1.position = targetPosition.position;
            transform1.rotation = Quaternion.identity;
            if (setActive)
            {
                item.gameObject.SetActive(true);
            }

            return item;
        }

        public T Get(Vector3 targetPosition, bool setActive = false)
        {
            var item = Get();
            item.transform.position = targetPosition;
            if (setActive)
            {
                item.gameObject.SetActive(true);
            }

            return item;
        }

        public void Return(T poolItem)
        {
            Pool.Add(poolItem);
        }

        private void SetupPool()
        {
            Pool = new List<T>();
            for (var i = 0; i < PoolLimit; i++)
            {
                var item = Instantiate(_defaultItem, Vector3.zero, Quaternion.identity, transform);
                item.gameObject.SetActive(false);
                Pool.Add(item);
                item.OnReturnToPool += () => Pool.Add(item);
            }
        }
    }
}