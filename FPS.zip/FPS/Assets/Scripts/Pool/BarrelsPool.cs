﻿using FPS.Entity;

namespace FPS.Pool
{
    public class BarrelsPool: AbstractPool<Barrel>
    {
    }
}