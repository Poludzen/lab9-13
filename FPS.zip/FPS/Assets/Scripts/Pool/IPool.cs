﻿using System.Collections.Generic;
using UnityEngine;

namespace FPS.Pool
{
    public interface IPool<T> where T : IPoolItem
    {
        int PoolLimit { get; set; }
        List<T> Pool { get; set; }
        T Get();
        T Get(Transform targetPosition, bool setActive = false);
        T Get(Vector3 targetPosition, bool setActive = false);
        void Return(T poolItem);
    }
}