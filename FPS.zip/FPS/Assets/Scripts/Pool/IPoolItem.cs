﻿using System;

namespace FPS.Pool
{
    public interface IPoolItem
    {
        event Action OnReturnToPool;
    }
}