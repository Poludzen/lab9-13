﻿namespace FPS.Pool
{
    public interface IPoolTarget
    {
        
    }
}