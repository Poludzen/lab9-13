﻿using FPS.Weapons;

namespace FPS.Pool
{
    public class ShootingParticlePool : AbstractPool<AbstractShootParticle>
    {
        public override int PoolLimit { get; set; } = 40;
    }
}