﻿using FPS.Entity;

namespace FPS.Pool
{
    public class SoldersPool: AbstractPool<Solder>
    {
        
    }
}