﻿using System;
using FPS.Actions;
using FPS.Entity;
using FPS.Pool;
using UnityEngine;

namespace FPS.Weapons
{
    public class AbstractShootParticle : MonoBehaviour, IPoolItem
    {
        [SerializeField] private float _flySpeed;
        [SerializeField] private Rigidbody _rigidBody;
        private IDealDamage _dealDamage;
        public event Action OnReturnToPool;

        private void OnEnable()
        {
            SetArgs(new DealNormalDamage());
        }

        private void OnCollisionEnter(Collision other)
        {
            Debug.Log("OnCollisionEnter");
            var applyAction = new ApplyAction(other.gameObject);
            applyAction.Add<IEntity>(_dealDamage.DealDamage);
            var result = applyAction.Run();
            gameObject.SetActive(false);
            OnReturnToPool?.Invoke();
        }

        public void SetArgs(IDealDamage dealDamage)
        {
            _dealDamage = dealDamage;
        }

        public void Fly(Vector3 target)
        {
            _rigidBody.velocity = target * _flySpeed;
        }
    }
}