﻿using System.Collections;
using UnityEngine;

namespace FPS.Weapons
{
    public class AbstractShootingWeapon : MonoBehaviour
    {
        [SerializeField] private Transform _shootParticleInitialPosition;
        [SerializeField] private float _shootDelay;
        public bool IsAvailableToShoot { get; set; } = true;

        public virtual void Fire(Vector3 direction)
        {
            var particle = Singleton.GameManager.ShootingParticlePool.Get(_shootParticleInitialPosition, true);
            particle.Fly(direction);
            IsAvailableToShoot = false;
            StartCoroutine(Reloading());
        }

        private IEnumerator Reloading()
        {
            yield return new WaitForSeconds(_shootDelay);
            IsAvailableToShoot = true;
        }
    }
}