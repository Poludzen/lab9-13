namespace FPS.Weapons
{
    public class Pistol : AbstractShootingWeapon
    {
    }
}